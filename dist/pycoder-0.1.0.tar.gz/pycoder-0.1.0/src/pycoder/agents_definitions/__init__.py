"""
Agent definitions for the Agents Windserf package.

This directory contains JSON definition files for pre-configured agents.
"""
